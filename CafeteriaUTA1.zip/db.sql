CREATE DATABASE Equipo4;
USE Equipo4;

CREATE TABLE Cafeteria(
IdPedido INT AUTO_INCREMENT PRIMARY KEY,
Nombre varchar(50),
Apellido VARCHAR(50),
Pedido TEXT,
Notas TEXT,
Sugerencia TEXT,
Hora TIME);

```